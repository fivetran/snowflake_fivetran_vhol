# google_ads_demo

The files in this folder are sample data produced by the Fivetran team to simulate Google Adwords data.

**These files are not required for the workshop.** They are provided for your convenience should you wish to use the CSV Uploader functionality of Fivetran rather than the Google Sheets connector as outlined in the Lab Guide

## Usage

To use in the lab in place of Google Sheets:

Use the CSV Uploader functionality of Fivetran. Use the schema name **google_ads_demo**, give the tables the same name as their filenames.